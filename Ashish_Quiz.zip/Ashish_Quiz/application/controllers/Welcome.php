<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Welcome extends MY_controller {

	 //load database
	
	function __construct() {
		parent::__construct();
		$this->load->database();
	}


//load welcome_game.php from view


	public function index()
	{
		$this->load->view('Game/welcome_game');
	}
	public function game()
	{		
		$userLevel = $_POST['Game_level'];
		$this->load->model('quizmodel');


//  if the choice of the level of the quiz  is easy


		if($userLevel == 'Easy')
		{	

			//loading getEasyQuestion function from the quiz model and and put inside an array called question.

			$this->data['questions'] = $this->quizmodel->getEasyQuestions();

			//loading the page game_easy from view and also loading the array ['question'] inside the view

			$this->load->view('Game/game_easy', $this->data);	
		}

		//  if the choice of the level of the quiz  is medium

		else if ($userLevel == 'Medium')
		{	
			$this->data['questions'] = $this->quizmodel->getMediumQuestions();
			$this->load->view('Game/game_medium', $this->data);	
		}
		else
		{	
			$this->data['questions'] = $this->quizmodel->getHardQuestions();
			$this->load->view('Game/game_hard', $this->data);	
		}			
	}
	public function resultEasyDisplay()
	{

		// create a array called check   and post each value user has selected

		$this->data['checks'] = array(
			'ques1' => $this->input->post('quizid1'),
			'ques2' => $this->input->post('quizid2'),
			'ques3' => $this->input->post('quizid3'),
			'ques4' => $this->input->post('quizid4'),
			'ques5' => $this->input->post('quizid5'),
		);

		// loading the model

		$this->load->model('quizmodel');
		$this->data['results'] = $this->quizmodel->getEasyQuestions();
		$this->load->view('Game/game_result_display', $this->data);
	}


	public function resultHardDisplay()
	{


		// create a array called check   and post each value user has selected


		$this->data['check'] = array(
			'ques1' => $this->input->post('quizid1'),
			'ques2' => $this->input->post('quizid2'),
			'ques3' => $this->input->post('quizid3'),
			'ques4' => $this->input->post('quizid4'),
			'ques5' => $this->input->post('quizid5'),
		);


		// loading the model


		$this->load->model('quizmodel');
		$this->data['results'] = $this->quizmodel->getHardQuestions();
		$this->load->view('Game/game_hard_result_display', $this->data);
	}



	public function resultMediumDisplay()
	{


		// create a array called check   and post each value user has selected


		$this->data['ceck'] = array(
			'ques1' => $this->input->post('quizid1'),
			'ques2' => $this->input->post('quizid2'),
			'ques3' => $this->input->post('quizid3'),
			'ques4' => $this->input->post('quizid4'),
			'ques5' => $this->input->post('quizid5'),
		);


		// loading the model


		$this->load->model('quizmodel');


		//loading getEasyQuestion function from the quiz model and and put inside an array called result.


		$this->data['results'] = $this->quizmodel->getMediumQuestions();


		//loading the page game_easy from view and also loading the array ['result'] 


		$this->load->view('Game/game_medium_result_display', $this->data);
	}

}
