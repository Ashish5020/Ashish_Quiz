<?php

class MY_CONTROLLER extends CI_Controller
{

}



?>