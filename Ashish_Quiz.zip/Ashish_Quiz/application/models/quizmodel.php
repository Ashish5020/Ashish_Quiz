 <?php
class quizmodel extends CI_Model
{
    public function getEasyQuestions()
    {


        //sql query to delect the the data from the table of the database

        $this->db->select("quizID,question,choice1,choice2,choice3,answer")
                          ->from('easy');
                          
        $query = $this->db->get();   //created a variable $query

        return $query->result();    //return the result

        $num_data_required = $query->num_rows;


         //if there is no data in the database will produce an error

        if ($num_data_required < 1) {
            echo "There is no data in the database";
            exit();
        }
    }

    public function getMediumQuestions()
    {
        $this->db->select("quizID,question,choice1,choice2,choice3,answer")
                          ->from('medium');
                          
        $query = $this->db->get();

        return $query->result();


        //if there is no data in the database will produce an error

        $num_data_required = $query->num_rows;

        if ($num_data_required < 1) {
            echo "There is no data in the database";
            exit();
        }
    }

    public function getHardQuestions()
    {
        $this->db->select("quizID,question,choice1,choice2,choice3,answer")
                          ->from('hard');
                          
        $query = $this->db->get();

        return $query->result();


        //if there is no data in the database will produce an error


        $num_data_required = $query->num_rows;

        if ($num_data_required < 1) {
            echo "There is no data in the database";
            exit();
        }
    }
    


   
    
}
?>