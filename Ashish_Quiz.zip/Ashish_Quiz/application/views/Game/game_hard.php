<html>
<head>
<title>Play Hard Quiz</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style >
	body {
    background-image: url("https://image.freepik.com/free-vector/white-minimal-background_1393-309.jpg");
    background-repeat: no-repeat;
  background-size: cover;
}
.grid-container {
width: 80%;
  display: grid;
  grid-template-columns: auto auto auto auto auto auto;
  grid-gap: 10px;

  background-color: #2196F3;
 border-radius: 10px;
  padding: 10px;
}
.grid-container > div {
 background-image: url("https://png.pngtree.com/thumb_back/fw800/back_our/20190622/ourmid/pngtree-simple-solid-color-cute-background-image_207553.jpg");
    background-repeat: no-repeat;
  background-size: cover;
  text-align: left;
 width: 158%;
  font-size: 29px;
}
</style>
</head>

<body><center><h1>Play the Hard Quiz!</h1>

	<!--sending all the user inputs to the controller function resultdisplay-->

<div class="grid-container">

<div id="container">
	

	<form method="post" action="<?php echo base_url();?>index.php/Welcome/resultHardDisplay">

		<!--storing each questions into another array called $row -->

	<?php foreach($questions as $row) { ?>

	<!--storing each questions into another array called $row -->

	<?php $ans_array = array($row->choice1, $row->choice2, $row->choice3, $row->answer);
	shuffle($ans_array); ?>

	 <!--displaying the question number(question id) and question-->

	<p><?=$row->quizID?>. <?=$row->question?></p>

	<!--displaying the radio buttons and performing the suffle-->


	<input type="radio" name="quizid<?=$row->quizID?>" value="<?=$ans_array[0]?>" required> <?=$ans_array[0]?> <br>
	<input type="radio" name="quizid<?=$row->quizID?>" value="<?=$ans_array[1]?>"> <?=$ans_array[1]?> <br>
	<input type="radio" name="quizid<?=$row->quizID?>" value="<?=$ans_array[2]?>"> <?=$ans_array[2]?> <br>
	<input type="radio" name="quizid<?=$row->quizID?>" value="<?=$ans_array[3]?>"> <?=$ans_array[3]?> <br>
	<?php } ?>
	<br><br>
	<input type="submit" value="Submit!">
	</form>
</div>
</div></center>
</body>
</html>