<!DOCTYPE html>
<html>
<head>
<title>Play Medium Quiz</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<style >
	body {
    background-image: url("https://cdn3.vectorstock.com/i/1000x1000/13/27/geometric-medical-concept-white-background-vector-24331327.jpg");
    background-repeat: no-repeat;
  background-size: cover;
}
.grid-container {
width: 80%;
  display: grid;
  grid-template-columns: auto auto auto auto auto auto;
  grid-gap: 10px;
  background-color: #2196F3;
 border-radius: 10px;
  padding: 10px;
}

.grid-container > div {
 background-image: url("https://image.freepik.com/free-photo/abstract-art-background-with-light-coral-pink-colors_113767-2983.jpg");
    background-repeat: no-repeat;
  background-size: cover;
  text-align: left;
 width: 164%;
  font-size: 29px;
}
</style>

</head>

<body><center>
<h1>Play the Medium Quiz!</h1>
<div class="grid-container">

<div id="container">
	

	<!-- sending all the user inputs to the controller function resultdisplay -->

	<form method="post" action="<?php echo base_url();?>index.php/Welcome/resultMediumDisplay">


		<!--storing each questions into another array called $row-->

	<?php foreach($questions as $row) { ?>

		<!-- storing each questions into another array called $row -->


	<?php $ans_array = array($row->choice1, $row->choice2, $row->choice3, $row->answer);
	shuffle($ans_array); ?>


	<!-- displaying the question number(question id) and question -->

	<p><?=$row->quizID?>. <?=$row->question?></p>

		<!-- displaying the radio buttons and performing the suffle-->

	<input type="radio" name="quizid<?=$row->quizID?>" value="<?=$ans_array[0]?>" required> <?=$ans_array[0]?> <br>
	<input type="radio" name="quizid<?=$row->quizID?>" value="<?=$ans_array[1]?>"> <?=$ans_array[1]?> <br>
	<input type="radio" name="quizid<?=$row->quizID?>" value="<?=$ans_array[2]?>"> <?=$ans_array[2]?> <br>
	<input type="radio" name="quizid<?=$row->quizID?>" value="<?=$ans_array[3]?>"> <?=$ans_array[3]?> <br>

	<?php } ?>

	<center>
	<input type="submit" value="Submit!">
</center>
	</form>







</div>

</div></center>
</body>

</html>