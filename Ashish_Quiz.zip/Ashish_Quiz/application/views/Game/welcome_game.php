
<html>
<head>
<title>Game</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
 /* Internal Css For Background Image*/
body {

    background-image: url("https://image.freepik.com/free-vector/neon-question-mark-frame-quiz-lighting-interrogation-point-red-neon-lamp-bricks-wall-texture-background-illustration_102902-1207.jpg");

    /*no-repeat for stop repetion of image*/
    background-repeat: no-repeat;

  background-size: cover;

}

.container {

 box-shadow:

 0 4px 8px 0 rgba(0,0,0,0.2); 

 margin:50px;

 width: 70%;

 height:200px;

 border-radius: 5px;

 text-align: center;
 
 padding: 10px;

}
table
 {
width: 100%;
}
tr
{
 text-align : center;
}
th {
  padding-top: 2px;
 padding-bottom: 12px; 
}
input[type=text] {
  width: 50%;
  padding: 12px 20px;
 display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
.w3-button 
{width:150px;
}
body,td,th {
    color: #ffffff;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<center><h1><br><b>Welcome to The General Knowledge Game<p>
  <br>
</p>Lets Start</h1></center>
<center>
<div class="container">




  <center><h1>Please Select your gaming level</h1></center>

  <!--sending  the user inputs to the controller function game-->

     <?php echo form_open('Welcome/game');?>
     <br>
      <table>
          <td style="border: 0 !important">
            <div class="input-group input-group-sm mb-3">
              <select name="Game_level" required="required" class="form-control">
                <option value="Easy" >Easy</option>
                <option value="Medium" >Medium</option>
                <option value="Hard" >Hard</option>
              </select>
            </div> 


       





           </td>   
      </table>
          <br><br>
    <?php echo form_submit(['type'=>'submit','class'=>'btn btn-default','value'=>'Start'])?>
    &nbsp&nbsp
            <?php echo form_reset(['type'=>'reset','class'=>'btn btn-primary','value'=>'Reset'])?>
    </div>
  </center>
<div>
</body>
</html>